const horariosConsultorios = {
  C1: { inicio: "07:00", fim: "16:00" },
  C2: { inicio: "07:00", fim: "16:00" },
  C3: { inicio: "08:00", fim: "17:00" },
  C4: { inicio: "10:00", fim: "19:00" },
  C5: { inicio: "12:00", fim: "21:00" },
  C6: { inicio: "07:00", fim: "19:00" },
  C7: { inicio: "07:00", fim: "19:00" },
  C8: { inicio: "07:00", fim: "19:00" },
};

export default horariosConsultorios;